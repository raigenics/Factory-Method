﻿namespace FactoryMethod.ProductInterface
{
    public interface IMobile
    {
        void GetMobile();
    }
}
